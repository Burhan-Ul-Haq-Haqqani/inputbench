# InputBench — Computer Skills Benchmark Lab

A crisp, light-mode precision benchmark lab that measures fundamental computer input skills across four dedicated modules: Click Speed (CPS), Typing Speed & Accuracy (WPM), Reaction Time, and a customizable 2-key rhythm mode featuring Nightcore and Half-Time Lo-Fi remixes for both built-in synth tracks and uploaded local audio files.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The scope and visual direction below reflect your confirmed choices from clarification. Review the two remix profiles and audio upload behavior before approving execution.

- **Confirmed Visual Aesthetic**: Crisp light-mode benchmark lab using clinical white/slate surfaces, 1px hairline grids, tabular monospace telemetry, and calibrated cobalt accents.
- **Confirmed Module Scope**: Strictly limited to the four core tests—Clicks Per Second (CPS), Words Per Minute & Typing Accuracy, Reaction Time, and 2-Key Rhythm Mode.
- **Confirmed Rhythm Audio Sources**: Supports both instant-play built-in Web Audio synth tracks and client-side local MP3/WAV/OGG file uploads.
- **Confirmed Remix Profiles**: Every track (built-in or uploaded) offers two distinct remixes: **Nightcore (1.30x Speed-Up)** and **Half-Time Lo-Fi (0.72x Slowed + Warm Low-Pass)**.

---

## 1. Overview & Core Concept

- **What It Does**: Provides an immediate, distraction-free web laboratory for measuring raw mouse click velocity, keyboard typing throughput and precision, visual-motor reaction latency, and two-finger rhythmic timing accuracy.
- **Target Audience / Persona**: PC gamers, mechanical keyboard enthusiasts, rhythm-game players, and everyday computer users benchmarking or training input speed and consistency.
- **Key Value**: Combines laboratory-grade high-resolution timing (`performance.now()` and Web Audio `AudioContext.currentTime`) with zero-setup browser execution—no accounts, downloads, or external servers required.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Lab Overview & Quick Launch**:
   - Users land on a clean light-mode benchmark hub displaying the four test modules in a structured 2×2 precision grid alongside their locally saved Personal Bests for each module.
   - Clicking any module card—or using the single-row top navigation bar—opens that test stage immediately with zero modal gates.
2. **Clicks Per Second (CPS)**:
   - Select duration (`1s`, `5s`, `10s`, `30s`). Timer arms and starts on the very first `pointerdown` inside the click pad so zero startup latency is lost.
   - Live tabular readouts display elapsed time, total clicks, rolling CPS, and an inline SVG click-rate sparkline.
   - Completing the interval locks the pad briefly (preventing accidental immediate restart) and reveals Peak CPS, Average CPS, and variance consistency.
3. **Words Per Minute & Typing Accuracy**:
   - Choose test mode (`15s`, `30s`, `60s`, or `25 Words`) and word set style.
   - Typing starts immediately on the first valid keypress inside the focused prompt stage. Characters render crisp color + underline feedback for correct, mistyped, and active cursor positions, supporting natural `Backspace` corrections.
   - Completion opens a telemetry breakdown with Net WPM, Raw WPM, Accuracy %, Character breakdown (`Correct / Incorrect`), and a WPM-over-time SVG curve.
4. **Reaction Time**:
   - Configure round count (`3`, `5`, or `10` trials).
   - Clicking the stage enters `Wait for Signal` (amber/slate warning state with explicit text label). Random delay (`1.5s`–`4.2s`) transitions to `Click Now!` (high-contrast emerald state + crisp visual glyph). Clicking early registers a `Too Early` fault and restarts the round cleanly.
   - Records `pointerdown` delta to sub-millisecond resolution, plotting per-round ms bars and calculating Average, Best, and Median latency.
5. **2-Key Rhythm Mode (Osu!mania Style + Two Remixes)**:
   - **Pre-Run Deck**: Select a built-in synth track or drop/upload any local `.mp3`, `.wav`, or `.ogg` file. Toggle between **Nightcore (1.30x)** and **Half-Time Lo-Fi (0.72x)** remixes, configure **2 custom keybinds** (click-to-capture any two distinct keys, defaulting to `D` and `K`), and fine-tune scroll speed and audio offset (`-100ms` to `+100ms`).
   - **Active Play Stage**: Dedicated 60fps HTML5 `<canvas>` vertical lane highway with two crisp receptors, falling rectangular notes, receptor press lighting, live judgment popups (`PERFECT`, `GOOD`, `OK`, `MISS`), combo counter, accuracy %, and playback progress bar. Both keyboard binds and direct mouse/touch receptor taps are supported.
   - **Results View**: Displays overall grade (`S+` through `C`), score, accuracy %, max combo, judgment distribution, and saves the Personal Best per song + remix combination.

### Visual Identity & Theme

- **Aesthetic Direction**: Clinical Precision Lab — flat, structured, high-legibility instrumentation inspired by metrology tools and clean industrial interfaces.
- **Color Palette & Mood (60-30-10 Budget)**:
  - *60% Dominant Canvas*: Pure white (`#FFFFFF`) and lab off-white (`#F8FAFC`).
  - *30% Structural Surfaces*: Cool slate panels (`#F1F5F9`), crisp `1px` hairline borders (`#E2E8F0`), deep charcoal primary text (`#0F172A`), and slate secondary metadata (`#475569`).
  - *10% Calibrated Accents*: Precision cobalt (`#2563EB`) for primary actions, active states, and Lane 1; deep indigo/cyan-slate (`#0284C7`) for Lane 2 contrast; semantic text-paired status colors (Emerald `#059669`, Amber `#D97706`, Rose `#E11D48`).
- **Typography & Hierarchy**:
  - *Display & UI*: `Plus Jakarta Sans` (weights `500`, `600`, `700`) with balanced headline wrapping.
  - *Telemetry & Counters*: `IBM Plex Mono` (`font-mono tabular-nums`) across all live timers, WPM, CPS, millisecond deltas, accuracy percentages, and keybind caps so numeric columns never jitter.
- **Component Styling & Layout**:
  - Strict 3-zone top bar: single-line brand wordmark (`InputBench`), 5 concise single-line nav links (`Overview`, `CPS`, `Typing`, `Reaction`, `Rhythm`), and 1 primary action (`Reset Records`).
  - Single-elevation flat cards with `1px` borders, generous whitespace, unboxed `·`-separated metadata, and zero decorative dots, pill badges, or thick left accent borders.

### Interactive Feedback & Motion

- Sub-150ms tactile transitions (`transform`, `opacity`) on receptor presses, click pad pulses, and active tab switches.
- High-contrast text + icon state indicators across Reaction Time and Rhythm judgments so no state relies on color alone.
- Web Audio API synthesized feedback chimes (optional mute toggle) for rhythm note hits and reaction readiness.

---

## 3. Key Product Decisions & Trade-Offs

- **Client-Side Audio Decoding & Onset Charting for Local Uploads**
  - *Chosen Approach*: Decode uploaded MP3/WAV files via the browser's `AudioContext.decodeAudioData()`, then run a fast client-side energy-flux onset detector across overlapping FFT/RMS windows to place rhythmic notes on transient peaks, alternating/patterning between the 2 lanes.
  - *Why*: Works completely offline with zero file upload latency or backend storage, ensuring any user song immediately becomes playable.
  - *Alternatives Considered*: Server-side Python audio processing (`librosa`) — rejected because it introduces network upload waits and unnecessary server dependencies for a responsive client tool.

- **Real-Time Web Audio Remixing Engine**
  - *Chosen Approach*: Drive both remixes from a single master audio representation:
    - *Nightcore Remix*: Runs audio at `1.30x` playback rate (naturally raising tempo and pitch like classic Nightcore), pairs with a subtle `+3dB` high-shelf EQ boost, increases note scroll speed, and unlocks extra half-beat syncopation notes.
    - *Half-Time Lo-Fi Remix*: Runs audio at `0.72x` playback rate, routes through a `BiquadFilterNode` low-pass filter (`~2.2kHz` warmth) with subtle soft-saturation/lo-fi ambience, and spaces the beatmap into a relaxed half-time pocket.
    - *Built-in Synth Tracks*: Uses a deterministic Web Audio step sequencer synced directly to `AudioContext.currentTime`, scaling step intervals and filter nodes identically for Nightcore vs. Half-Time Lo-Fi.
  - *Why*: Guarantees rock-solid audio-to-note synchronization (no `HTMLAudioElement` drift) and gives any song two genuinely distinct musical feels and difficulty curves.
  - *Alternatives Considered*: Pre-rendered static MP3 assets — rejected because uploaded user tracks could not share the same remix engine.

- **Local Persistence Strategy**
  - *Chosen Approach*: Store Personal Bests, recent run history (last 10 runs per module), custom 2-key bindings, and audio calibration offset in `localStorage`.
  - *Why*: Zero-friction instant load with persistent progress across refreshes.
  - *Alternatives Considered*: Cloud database + authentication — unnecessary friction given the strict 4-test utility scope.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          App Shell & Top Bar                            │
│  ┌──────────────┐   ┌────────────────────────────────────────────────┐  │
│  │ Active Route │──▶│ Local Benchmark Store (Personal Bests & Prefs) │  │
│  └──────┬───────┘   └────────────────────────────────────────────────┘  │
└─────────┼───────────────────────────────────────────────────────────────┘
          │
          ├──────────────────┬──────────────────┬──────────────────┐
          ▼                  ▼                  ▼                  ▼
┌──────────────────┐ ┌──────────────┐ ┌──────────────────┐ ┌───────────────────┐
│   CPS Module     │ │ Typing Lab   │ │ Reaction Module  │ │  2-Key Rhythm Lab │
│ - Pointer timing │ │ - Word stream│ │ - Random delay   │ │ - Setup & Keybind │
│ - Sparkline SVG  │ │ - WPM curve  │ │ - Trial bars     │ │ - 60fps Canvas    │
└──────────────────┘ └──────────────┘ └──────────────────┘ └─────────┬─────────┘
                                                                     │
                                            ┌────────────────────────┴────────┐
                                            ▼                                 ▼
                                  ┌───────────────────┐             ┌───────────────────┐
                                  │  Web Audio Engine │             │  Beatmap Engine   │
                                  │ - Synth Sequencer │             │ - Preset Charts   │
                                  │ - Buffer Playback │             │ - Onset Detector  │
                                  │ - Nightcore 1.30x │             │ - Nightcore/LoFi  │
                                  │ - Lo-Fi 0.72x LPF │             │   Chart Transform │
                                  └───────────────────┘             └───────────────────┘
```

### Data Model & State

- **Benchmark Store (`localStorage`)**:
  - `personalBests`: Best CPS (by duration), Best Net WPM & Accuracy, Fastest Reaction Average & Single Trial (ms), and Rhythm High Score / Accuracy / Grade keyed by `(trackId, remixMode)`.
  - `recentRuns`: Bounded circular list of recent test results per module for trend visibility on the Overview hub.
  - `rhythmConfig`: `{ leftKey: string, rightKey: string, scrollSpeed: number, audioOffsetMs: number, hitSounds: boolean }`.
- **Rhythm Track & Chart Model**:
  - `RhythmTrack`: `{ id, title, artistOrStyle, sourceType: 'synth' | 'upload', baseBpm, durationSec, buffer?: AudioBuffer, synthPattern?: SynthPreset }`.
  - `RemixMode`: `'nightcore' | 'lofi'`.
  - `NoteEvent`: `{ id, timeSec, lane: 0 | 1, hitStatus?: 'perfect' | 'good' | 'ok' | 'miss' }`.

### Interactive Component & State Mapping

- **Overview Hub**: Reads from the Benchmark Store to populate the 4 module launch cards and recent personal-best summary metrics; clicking any module switches the active view cleanly.
- **CPS Stage**: State machine (`IDLE` → `RUNNING` → `COOLDOWN_RESULTS`). `onPointerDown` increments click count, captures timestamps in a sliding 1-second window for real-time CPS, and samples interval buckets for the sparkline chart.
- **Typing Stage**: State machine (`READY` → `TYPING` → `FINISHED`). Global `keydown` listener (scoped when typing arena is active) tracks typed characters, cursor index, errors, and 1-second WPM snapshots; handles `Tab` or `Restart` button cleanly without leaking listeners.
- **Reaction Stage**: State machine (`IDLE` → `WAITING` → `GO` → `EARLY_FAULT` → `ROUND_RESULT` → `SUMMARY`). Uses `setTimeout` + `performance.now()` on `requestAnimationFrame` paint alignment; cleans up timers on unmount or early click.
- **2-Key Rhythm Stage**:
  - *Keybind Capture*: Clicking either lane's key button enters capture mode for that lane, listens for the next `keydown`, rejects reserved browser/escape keys or duplicate assignments across lanes, and saves immediately.
  - *Audio Upload*: File dropzone / picker validates audio MIME/extension, decodes `ArrayBuffer` via `AudioContext.decodeAudioData()`, displays an inline loading state during onset analysis, and generates both Nightcore and Half-Time Lo-Fi playable charts or surfaces a clear error banner if decoding fails.
  - *Canvas Loop*: `requestAnimationFrame` calculates exact elapsed song time from `audioCtx.currentTime - startTime + offset`, draws falling notes and receptor states, evaluates keydown hits against judgment windows (`±45ms`, `±95ms`, `±140ms`), and automatically transitions to the summary view when audio completes.
